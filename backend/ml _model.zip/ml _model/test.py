from infer import model_predict

preds = model_predict("realtime_flow_features.csv")
print("Predictions:", preds)
